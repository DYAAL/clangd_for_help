**bus**

![alt text](image-1.png)

**device**
![alt text](image-4.png)
![alt text](image-2.png)

**device_driver**

![alt text](image-3.png)

