#ifndef __SR04_MAIN_DRV_H__
#define __SR04_MAIN_DRV_H__

#include "dev_drv.h"
#include "driver_drv.h"

extern Device_Register_Struct_P device_register_struct_ps[MAX_MINOR];
extern Driver_Register_Struct_P driver_register_struct_p;

#endif // __SR04_MAIN_DRV_H__