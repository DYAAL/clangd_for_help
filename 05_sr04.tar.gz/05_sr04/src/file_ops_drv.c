
#include "linux/device.h"
#include "linux/err.h"
#include "linux/gpio/consumer.h"
#include "linux/wait.h"
#include <asm/uaccess.h>
#include <linux/slab.h>




ssize_t my_read(struct file* filp, char __user* usr_buf, size_t size, loff_t* offset)
{
    // int minor = MINOR(filp->f_inode->i_rdev);
    // int len = (size < 4) ? size : 4;
    // wait_event_interruptible(device_resources[minor].wait_queue, device_resources[minor].whether_data);
    // int value = gpiod_get_value(device_resources[minor].gpio_desc_p);
    // int ret = copy_to_user(usr_buf, &value, len);
    // if (IS_ERR_VALUE(ret)) {
    //     printk(KERN_ERR "copy_to_user failed\n");
    //     printk(KERN_ERR "file: %s, function: %s, line: %d\n", __FILE__, __func__, __LINE__);
    //     return -EFAULT;
    // }
    // device_resources[minor].whether_data = 0;
    // return len;
};

ssize_t my_write(struct file* filp, const char __user* usr_buf, size_t size, loff_t* offset)
{

    return 0;
};
int my_open(struct inode* inode_p, struct file* filp)
{

    return 0;
};

int my_release(struct inode* inode_p, struct file* filp)
{
    return 0;
};
struct file_operations sr04_drv_fops = {
    .open = my_open,
    .release = my_release,
    .read = my_read,
    .write = my_write,
};