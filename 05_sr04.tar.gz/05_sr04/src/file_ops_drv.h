#ifndef __OPS_DRV_H__
#define __OPS_DRV_H__

extern struct file_operations sr04_drv_fops;
#endif // __OPS_DRV_H__