
#include <fcntl.h> // 需要使用 open 函数
#include <sys/poll.h>
#include <unistd.h> // 需要使用 close 函数
int main(int argc, char* argv[])
{
    int fd = open(argv[1], O_RDONLY); // 打开文件
}